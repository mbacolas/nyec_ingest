from pyspark.sql import SparkSession

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DateType
from pyspark.sql.functions import *
from datetime import datetime, timedelta, date

# Create SparkSession
spark = SparkSession.builder \
      .master("local[1]") \
      .appName("SparkByExamples.com") \
      .getOrCreate()

# columns = ["firstname","middlename","lastname","dob","gender","salary"]
# df = spark.createDataFrame(data=data, schema = columns)

# return ['PATIENT_ID', 'PAT_BRTH_YR_NBR', 'PAT_GENDER_CD']

patient_schema = StructType([ \
    StructField("PATIENT_ID",StringType(),False), \
    StructField("DOB_YEAR",IntegerType(),True), \
    StructField("GENDER",StringType(),True)
  ])

claim_schema = StructType([ \
    StructField("MONTH_ID",StringType(),False), \
    StructField("SVC_DT",DateType(),False), \
    StructField("PATIENT_ID",StringType(),False), \
    StructField("PAT_ZIP3",StringType(),False), \
    StructField("CLAIM_ID",StringType(),False), \
    StructField("SVC_NBR",StringType(),False), \
    StructField("DIAG_CD_POSN_NBR",StringType(),True), \
    StructField("CLAIM_TYP_CD",StringType(),False), \
    StructField("RENDERING_PROVIDER_ID",StringType(),True), \
    StructField("REFERRING_PROVIDER_ID",StringType(),True), \
    StructField("PLACE_OF_SVC_NM",StringType(),True), \
    StructField("PLAN_ID",StringType(),True), \
    StructField("PAY_TYP_DESC",StringType(),True), \
    StructField("DIAG_CD",StringType(),True), \
    StructField("DIAG_VERS_TYP_ID",StringType(),True), \
    StructField("PRC_CD",StringType(),True), \
    StructField("PRC_VERS_TYP_ID",StringType(),True), \
    StructField("PRC1_MODR_CD",StringType(),True), \
    StructField("PRC2_MODR_CD",StringType(),True), \
    StructField("PRC3_MODR_CD",StringType(),True), \
    StructField("PRC4_MODR_CD",StringType(),True), \
    StructField("NDC_CD",StringType(),True), \
    StructField("SVC_CRGD_AMT",StringType(),True), \
    StructField("UNIT_OF_SVC_AMT",StringType(),True), \
    StructField("HOSP_ADMT_DT",DateType(),True), \
    StructField("HOSP_DISCHG_DT",DateType(),True), \
    StructField("SVC_FR_DT",DateType(),False), \
    StructField("SVC_TO_DT",DateType(),True), \
    StructField("CLAIM_HOSP_REV_CD",StringType(),True), \
    StructField("FCLT_TYP_CD",StringType(),True), \
    StructField("ADMS_SRC_CD",StringType(),True), \
    StructField("ADMS_TYP_CD",StringType(),True), \
    StructField("ADMS_DIAG_CD",StringType(),True), \
    StructField("ADMS_DIAG_VERS_TYP_ID",StringType(),True)
  ])

patient_path = "/tmp/patient.csv"
claim_path = "/tmp/claim.csv"

patient_raw = spark.read.schema(patient_schema).options(inferSchema=False,delimiter=',', header=True).csv(patient_path)
claim_raw = spark.read.schema(claim_schema).options(inferSchema=False,delimiter=',', header=True).csv(claim_path)

# # patient_raw = spark.read.options(inferSchema=True,delimiter=',', header=True).csv(patient_path)
# patient_df = patient_raw.withColumnRenamed("PATIENT_ID","patient_id")\
#                 .withColumnRenamed("PAT_BRTH_YR_NBR", "dob_year") \
#                 .withColumnRenamed("PAT_GENDER_CD", "gender")



@udf(returnType=StringType())
def to_dob(year: int) -> date:
    dob = str(year)+'-01-01'
    return datetime.strptime(dob, "%Y-%m-%d").date()


udf_star_desc = udf(lambda year:to_dob(year),DateType())

test = claims_raw.select(col('CLAIM_ID'), col('SVC_NBR'), col('CLAIM_TYP_CD'), col('SVC_FR_DT'), col('SVC_TO_DT'), col('HOSP_ADMT_DT'))
test.withColumn("CLAIM_TYP_CD",udf_star_desc(col("CLAIM_TYP_CD")))  #.select(col('CLAIM_ID'), col('SVC_NBR'), col('CLAIM_TYP_CD'), col('SVC_FR_DT'), col('SVC_TO_DT')).first()
test.withColumn("CLAIM_TYP_CD",func1("CLAIM_TYP_CD"))
claims_raw.withColumn(col('CLAIM_ID'), lambda x: 'ABC')


from pyspark.sql.functions import when
df2 = test.withColumn("type", when(test.CLAIM_TYP_CD == "I","INPATIENT")
                                 .when(test.CLAIM_TYP_CD == "P","OUTPATIENT")
                                 # .when(test.CLAIM_TYP_CD.isNull() ,"")
                                 .otherwise(test.CLAIM_TYP_CD)) \
    .withColumn('sub_type', when(test.HOSP_ADMT_DT.isNull() ,"OUTPATIENT"))

# df.withColumn("Cureated Name", upperCase(col("Name"))) \
# .show(truncate=False)

test = claims_raw.select(col('CLAIM_ID'), col('SVC_NBR'), transform(col('CLAIM_TYP_CD'), lambda x: x), col('SVC_FR_DT'), col('SVC_TO_DT'))
test2 = test.select(transform('CLAIM_TYP_CD', lambda x: 'ABC'))
test2 = test.select(transform('CLAIM_TYP_CD', func1))



    return sub_type

test2 = test.map(lambda x:  (func1(x)))

def test(df):
    return
test.transform()






#### IGNORE

#.schema(patient_schema)\
patient_df = spark.read.option("delimiter", ",")\
                        .option("inferSchema", True)\
                        .option("header", True)\
                        .csv(patient_path)

patient_df.columns==['PATIENT_ID', 'PAT_BRTH_YR_NBR', 'PAT_GENDER_CD']
patient_df.columns==['PAT_BRTH_YR_NBR', 'PATIENT_ID', 'PAT_GENDER_CD']
patient_schema.fieldNames()
patient_df.schema.fields
